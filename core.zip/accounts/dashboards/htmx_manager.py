from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.db.models import Sum
from django.utils import timezone

from payments.models import Payment
from .helpers import get_user_branch


@login_required
def manager_stats(request):

    branch = get_user_branch(request.user)
    today = timezone.now().date()

    payments_today = Payment.objects.filter(
        branch=branch,
        created_at__date=today
    )

    total_today = payments_today.aggregate(
        total=Sum("amount")
    )["total"] or 0

    context = {
        "total_today": total_today,
        "payments_count": payments_today.count(),
    }

    return render(
        request,
        "dashboard/manager/partials/stats.html",
        context,
    )


@login_required
def manager_recent_inscriptions(request):

    branch = get_user_branch(request.user)

    inscriptions = (
        Inscription.objects
        .filter(branch=branch)
        .select_related("student", "programme")
        .order_by("-created_at")[:10]
    )

    return render(
        request,
        "dashboard/manager/partials/inscriptions.html",
        {
            "inscriptions": inscriptions
        }
    )


@login_required
def manager_recent_payments(request):

    branch = get_user_branch(request.user)

    payments = (
        Payment.objects
        .filter(branch=branch)
        .select_related("student")
        .order_by("-created_at")[:10]
    )

    return render(
        request,
        "dashboard/manager/partials/payments.html",
        {
            "payments": payments
        }
    )