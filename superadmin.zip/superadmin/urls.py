from django.urls import path
from . import views

app_name = "superadmin"

urlpatterns = [

    path('', views.dashboard, name='dashboard'),

    # FORMATIONS
    path('formations/', views.formation_list, name='formation_list'),
    path('formations/create/', views.formation_create, name='formation_create'),
    path('formations/<int:pk>/edit/', views.formation_edit, name='formation_edit'),

    # ACTIONS
    path('formations/<int:pk>/toggle/', views.toggle_formation, name='formation_toggle'),

]