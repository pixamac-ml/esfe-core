from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.db.models import Sum
from django.utils import timezone

from inscriptions.models import Inscription
from payments.models import Payment

from accounts.dashboards.helpers import (
    get_user_branch,
    is_manager
)


@login_required
def manager_dashboard(request):
    """
    Dashboard principal de la gestionnaire.

    Fonctions :
    - voir les inscriptions de son annexe
    - voir les paiements
    - suivre les paiements du jour
    """

    # Sécurité : seul un gestionnaire peut accéder
    if not is_manager(request.user):
        return redirect("accounts:dashboard_redirect")

    # récupération annexe utilisateur
    branch = get_user_branch(request.user)

    # sécurité supplémentaire
    if not branch:
        return render(request, "403.html")

    today = timezone.now().date()

    # ==========================
    # INSCRIPTIONS
    # ==========================

    inscriptions = (
        Inscription.objects
        .filter(candidature__branch=branch)
        .select_related(
            "student",
            "candidature",
        )
        .order_by("-created_at")[:10]
    )

    # ==========================
    # PAIEMENTS DU JOUR
    # ==========================

    payments_today = (
        Payment.objects
        .filter(
            inscription__candidature__branch=branch,
            created_at__date=today
        )
        .select_related("inscription", "inscription__student")
    )

    # ==========================
    # TOTAL ENCAISSÉ
    # ==========================

    total_today = (
        payments_today.aggregate(
            total=Sum("amount")
        )["total"] or 0
    )

    # ==========================
    # PAIEMENTS EN ATTENTE
    # ==========================

    pending_payments = (
        Payment.objects
        .filter(
            inscription__candidature__branch=branch,
            status="pending"
        )
        .count()
    )

    context = {
        "inscriptions": inscriptions,
        "payments_today": payments_today,
        "total_today": total_today,
        "pending_payments": pending_payments,
        "branch": branch,
    }

    return render(
        request,
        "dashboard/dashboard.html",
        context
    )