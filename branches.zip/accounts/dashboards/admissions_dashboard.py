# accounts/dashboards/admissions_dashboard.py

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Q
from django.utils import timezone
from django.core.paginator import Paginator
from datetime import timedelta

from admissions.models import Candidature, CandidatureDocument
from formations.models import Programme
from branches.models import Branch

from .helpers import get_user_branch
from .permissions import check_admissions_access, is_global_viewer
from .querysets import get_base_queryset


@login_required
def admissions_dashboard(request):

    user = request.user

    if not check_admissions_access(user):
        messages.error(request, "Accès refusé.")
        return redirect("core:home")

    branch = get_user_branch(user)
    is_global = is_global_viewer(user)

    # =========================
    # QUERYSET BASE OPTIMISÉ
    # =========================

    candidatures = (
        get_base_queryset(user, "candidature")
        .select_related(
            "programme",
            "branch"
        )
    )

    # =========================
    # FILTRES
    # =========================

    status = request.GET.get("status")
    programme = request.GET.get("programme")
    search = request.GET.get("q")
    branch_filter = request.GET.get("branch")

    if status:
        candidatures = candidatures.filter(status=status)

    if programme:
        candidatures = candidatures.filter(programme_id=programme)

    if branch_filter and is_global:
        candidatures = candidatures.filter(branch_id=branch_filter)

    if search:
        candidatures = candidatures.filter(
            Q(first_name__icontains=search)
            | Q(last_name__icontains=search)
            | Q(email__icontains=search)
        )

    # =========================
    # STATS GÉNÉRALES
    # =========================

    stats = candidatures.aggregate(

        total=Count("id"),

        submitted=Count(
            "id",
            filter=Q(status="submitted")
        ),

        reviewing=Count(
            "id",
            filter=Q(status="under_review")
        ),

        accepted=Count(
            "id",
            filter=Q(status="accepted")
        ),

        rejected=Count(
            "id",
            filter=Q(status="rejected")
        ),

    )

    # =========================
    # STATS RÉCENTES
    # =========================

    week_ago = timezone.now() - timedelta(days=7)

    recent = candidatures.filter(
        submitted_at__gte=week_ago
    ).count()

    today = timezone.now().date()

    today_count = candidatures.filter(
        submitted_at__date=today
    ).count()

    # =========================
    # DOCUMENTS À VALIDER
    # =========================

    pending_docs = (
        CandidatureDocument.objects
        .filter(
            candidature__in=candidatures,
            is_valid=False
        )
        .select_related(
            "candidature",
            "document_type"
        )
        .order_by("-uploaded_at")[:20]
    )

    # =========================
    # TRI
    # =========================

    order = request.GET.get("order")

    if order == "oldest":
        candidatures = candidatures.order_by("submitted_at")

    elif order == "name":
        candidatures = candidatures.order_by("last_name")

    else:
        candidatures = candidatures.order_by("-submitted_at")

    # =========================
    # PAGINATION
    # =========================

    paginator = Paginator(candidatures, 25)

    page = request.GET.get("page")

    candidatures_page = paginator.get_page(page)

    # =========================
    # PROGRAMMES
    # =========================

    programmes = Programme.objects.all()

    # =========================
    # ANNEXES (GLOBAL ONLY)
    # =========================

    branches = None

    if is_global:

        branches = (
            Branch.objects
            .filter(is_active=True)
            .order_by("name")
        )

    # =========================
    # CONTEXTE
    # =========================

    context = {

        "stats": stats,

        "recent": recent,
        "today_count": today_count,

        "pending_docs": pending_docs,

        "candidatures": candidatures_page,

        "programmes": programmes,

        "branches": branches,

        "dashboard_type": "admissions",

        "branch": branch,
        "is_global": is_global,

    }

    return render(
        request,
        "accounts/dashboard/admissions.html",
        context
    )