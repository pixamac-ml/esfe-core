from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import user_passes_test
from django.http import HttpResponse

from formations.models import Programme


def superuser_required(user):
    return user.is_superuser


@user_passes_test(superuser_required)
def dashboard(request):
    return render(request, "superadmin/dashboard.html", {
        "formations_count": Programme.objects.count()
    })


@user_passes_test(superuser_required)
def formation_list(request):
    formations = Programme.objects.all().order_by("-id")

    return render(request, "superadmin/formations/list.html", {
        "formations": formations
    })


@user_passes_test(superuser_required)
def formation_create(request):
    if request.method == "POST":
        title = request.POST.get("title")

        Programme.objects.create(
            title=title,
            duration_years=3,
            short_description="Temporaire",
            description="Temporaire"
        )

        return redirect("superadmin:formation_list")

    return render(request, "superadmin/formations/form.html")


@user_passes_test(superuser_required)
def formation_edit(request, pk):
    formation = get_object_or_404(Programme, pk=pk)

    if request.method == "POST":
        formation.title = request.POST.get("title")
        formation.save()

        return redirect("superadmin:formation_list")

    return render(request, "superadmin/formations/form.html", {
        "formation": formation
    })


@user_passes_test(superuser_required)
def toggle_formation(request, pk):
    formation = get_object_or_404(Programme, pk=pk)

    formation.is_active = not formation.is_active
    formation.save()

    return HttpResponse("OK")